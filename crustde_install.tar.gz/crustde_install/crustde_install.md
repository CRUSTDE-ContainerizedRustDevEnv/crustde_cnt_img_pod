# crustde_install

Download and run the first script.  

```bash
curl -sSf -L https://github.com/CRUSTDE-ContainerizedRustDevEnv/crustde_cnt_img_pod/raw/main/crustde_install/download_scripts.sh | sh
```

Then follow the instructions and explanation in the scripts.  
There will be a few scripts to run for different steps.  
